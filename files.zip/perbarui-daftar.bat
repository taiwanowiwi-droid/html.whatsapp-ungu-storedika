@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0perbarui-daftar.ps1"
echo.
pause
