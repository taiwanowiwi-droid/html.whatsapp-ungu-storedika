$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$files = @(Get-ChildItem -Path $dir -File | Where-Object { $_.Extension -match '^\.(mp3|m4a|wav|ogg|aac)$' } | Sort-Object Name | ForEach-Object { $_.Name })
$json = ConvertTo-Json -InputObject $files -Compress
if ($files.Count -eq 0) { $json = '[]' }
[IO.File]::WriteAllText((Join-Path $dir 'daftar.js'), "window.DAFTAR_LAGU=$json;", (New-Object Text.UTF8Encoding $false))
Write-Host "Daftar lagu diperbarui: $($files.Count) lagu."
