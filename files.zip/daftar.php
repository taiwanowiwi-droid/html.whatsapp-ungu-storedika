<?php
// Otomatis: membaca semua file audio di folder ini (untuk hosting yang mendukung PHP).
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$f = [];
foreach (scandir(__DIR__) as $x) {
  if (preg_match('/\.(mp3|m4a|wav|ogg|aac)$/i', $x)) $f[] = $x;
}
sort($f, SORT_NATURAL | SORT_FLAG_CASE);
echo json_encode($f, JSON_UNESCAPED_UNICODE);
